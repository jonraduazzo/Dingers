//
//  ContentView.swift
//  Dingers Prototype
//
//  Created by Justin DeVuono on 12/15/24.
//

import SwiftUI
import PhotosUI  // For video selection
import AVKit  // For video playback
import AVFoundation  // For audio session configuration
import UIKit  // For landscape orientation control

struct ContentView: View {
    @State private var isShowingVideoPicker = false  // Track if the video picker is shown
    @State private var videoURL: URL?  // Store the selected video URL

    var body: some View {
        NavigationStack {
            VStack {
                Button(action: {
                    isShowingVideoPicker = true
                }) {
                    Text("Select Video")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $isShowingVideoPicker) {
                    VideoPicker(videoURL: $videoURL)
                }

                if let videoURL = videoURL {
                    NavigationLink(
                        destination: VideoPlayerView(videoURL: videoURL).onDisappear {
                            self.videoURL = nil
                        }
                    ) {
                        Text("Play Selected Video")
                            .padding()
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
            }
            .navigationTitle("Dingers Prototype")
        }
    }
}

struct VideoPlayerView: UIViewControllerRepresentable {
    let videoURL: URL

    func makeUIViewController(context: Context) -> UIViewController {
        configureAudioSession()  // Ensure audio plays in silent mode
        let landscapeController = LandscapeLockedViewController()
        let player = AVPlayer(url: videoURL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player

        // Disable video controls
        playerViewController.showsPlaybackControls = false

        // Determine if video should open in landscape mode
        let asset = AVAsset(url: videoURL)
        asset.loadTracks(withMediaType: .video) { tracks, error in
            if let track = tracks?.first {
                Task {
                    do {
                        let naturalSize = try await track.load(.naturalSize)
                        let preferredTransform = try await track.load(.preferredTransform)
                        let transformedSize = naturalSize.applying(preferredTransform)

                        if abs(transformedSize.width) > abs(transformedSize.height) {
                            DispatchQueue.main.async {
                                landscapeController.forceLandscapeOrientation()  // Open in landscape
                            }
                        }
                    } catch {
                        print("Error loading track properties: \(error.localizedDescription)")
                    }
                }
            }
        }

        playerViewController.videoGravity = .resizeAspectFill  // Ensure video is fully zoomed in

        // Embed the AVPlayerViewController inside the landscape-locked view controller
        landscapeController.addChild(playerViewController)
        landscapeController.view.addSubview(playerViewController.view)
        playerViewController.view.frame = landscapeController.view.bounds
        playerViewController.didMove(toParent: landscapeController)

        player.play()  // Start playback
        return landscapeController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to configure audio session: \(error.localizedDescription)")
        }
    }
}

class LandscapeLockedViewController: UIViewController {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }

    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .landscapeRight
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func forceLandscapeOrientation() {
        guard let windowScene = view.window?.windowScene else {
            print("Unable to access window scene")
            return
        }

        let geometryPreferences = UIWindowScene.GeometryPreferences.iOS(interfaceOrientations: .landscape)
        windowScene.requestGeometryUpdate(geometryPreferences) { error in
            if let nsError = error as NSError? {
                print("Error forcing landscape orientation: \(nsError.localizedDescription)")
            }
        }
    }
}

struct VideoPicker: UIViewControllerRepresentable {
    @Binding var videoURL: URL?

    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration(photoLibrary: PHPhotoLibrary.shared())
        config.filter = .videos
        config.selectionLimit = 1

        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        var parent: VideoPicker

        init(_ parent: VideoPicker) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)

            guard let provider = results.first?.itemProvider else {
                print("No video selected")
                return
            }

            print("Item provider found: \(provider)")

            if provider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) {
                provider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { (tempURL, error) in
                    guard let tempURL = tempURL else {
                        print("Error loading file: (error?.localizedDescription ?? \"Unknown error\")")
                        return
                    }

                    print("Temporary file URL: \(tempURL)")

                    // Securely copy the file to the app's temporary directory
                    let fileManager = FileManager.default
                    let tempDir = fileManager.temporaryDirectory
                    let destinationURL = tempDir.appendingPathComponent(tempURL.lastPathComponent)

                    do {
                        if fileManager.fileExists(atPath: destinationURL.path) {
                            try fileManager.removeItem(at: destinationURL)
                        }
                        try fileManager.copyItem(at: tempURL, to: destinationURL)
                        print("Copied video to temporary directory: \(destinationURL)")

                        // Pass the new URL back to ContentView
                        DispatchQueue.main.async {
                            self.parent.videoURL = destinationURL
                            print("Updated video URL to: \(destinationURL)")
                        }
                    } catch {
                        print("Error copying video file: \(error.localizedDescription)")
                    }
                }
            } else {
                print("Selected item is not a video")
            }
        }
    }
}

